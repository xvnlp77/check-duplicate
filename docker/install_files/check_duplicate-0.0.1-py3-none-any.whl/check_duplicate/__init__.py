"""
@Author  : chouxiaohui
@Date    : 2021/1/26 10:23 上午
@Version : 1.0
"""

from check_duplicate.web.run import app